<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('subscription_payment_requests', function (Blueprint $table) {
            $table->foreignId('admin_id')
                ->nullable()
                ->after('subscription_id')
                ->constrained('admins')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('subscription_payment_requests', function (Blueprint $table) {
            $table->dropConstrainedForeignId('admin_id');
        });
    }
};
