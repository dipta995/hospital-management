<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <script>document.write(new Date().getFullYear())</script> &copy; DreamMakeSoft. Crafted by  <a
                    href="dreammake-soft.com" class="fw-bold footer-text" target="_blank">Dipta</a>
            </div>
        </div>
    </div>
</footer>
