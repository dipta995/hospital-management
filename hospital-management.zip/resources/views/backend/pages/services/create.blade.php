@extends('backend.layouts.master')
@section('title')
    Create New {{ $pageHeader['title'] }}
@endsection
@section('admin-content')
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Create New {{ $pageHeader['title'] }}</h4>
                        @include('backend.layouts.partials.message')
                        <form method="POST" action="{{ route($pageHeader['store_route']) }}">
                            @csrf
                            <div class="form-group col-md-6">
                                <div class="form-group">
                                    <x-default.label required="true" for="service_category_id">Category</x-default.label>
                                    <select class="form-control" name="service_category_id" id="service_category_id">
                                        <option value="">--Choose--</option>
                                        @foreach($categories as $item)
                                            <option value="{{ $item->id }}">{{ $item->name }}</option>
                                        @endforeach
                                    </select>
                                    <x-default.input-error name="service_category_id"></x-default.input-error>
                                </div>
                            </div>
                            <div class="form-group">
                                <x-default.label required="true" for="name">Name</x-default.label>
                                <x-default.input name="name" class="form-control" id="name" type="text"/>
                                <x-default.input-error name="name"/>
                            </div>
                            <div class="form-group">
                                <x-default.label required="true" for="price">Price</x-default.label>
                                <x-default.input name="price" class="form-control" id="price" type="number" step="0.01"/>
                                <x-default.input-error name="price"/>
                            </div>
                            <div class="form-group">
                                <x-default.label for="note">Note</x-default.label>
                                <textarea name="note" id="note" class="form-control" rows="3"></textarea>
                                <x-default.input-error name="note"/>
                            </div>
                            <x-default.button class="float-end mt-2 btn-success">Create</x-default.button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
