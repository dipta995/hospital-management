    @error($name)
    <strong class="text-danger">{{ $errors->first($name) }}</strong>
    @enderror
