<label {{ $attributes->merge(['for' => $for]) }}>
    {{ $slot }}
</label>
